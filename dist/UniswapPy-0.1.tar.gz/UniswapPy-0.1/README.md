# UniswapPy
Uniswap for python

The purpose of this package is to model behavior for the Uniswap V2 
protocol using python

To install package:
```
> git clone https://github.com/icmoore/uniswappy
> pip install .
```
